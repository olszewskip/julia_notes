# Modifiers

Interact provides some modifiers to change an existing widget (or return a tranformed version of the widget):

```@docs
InteractBase.tooltip!
onchange
```
